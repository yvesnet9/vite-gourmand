ECF - DÉVELOPPEUR WEB ET WEB MOBILE
Projet : Vite & Gourmand

Candidat : Jamesy MUKUNA MUKENKETAYI
Email : yvesnet9@gmail.com
Session : Juin-Juillet 2026
Formation : Graduate Développeur Web Full Stack - STUDI Paris

=== CONTENU DU DOSSIER ===

01_ECF_STUDI.pdf
  - Informations candidat
  - Analyse des besoins
  - Spécifications techniques
  - Recherche (récupération SSH)
  - Liens : GitHub, Trello, Application

02_DOSSIER_PROJET.pdf
  - Documentation technique complète (75 pages)
  - Architecture détaillée
  - Captures d'écran
  - Guide utilisateur
  - Charte graphique

03_PRESENTATION.pdf
  - Support PowerPoint de soutenance (18 slides)
  - Démonstration en 4 étapes
  - Métriques et perspectives

=== LIENS IMPORTANTS ===

Application : https://vite-gourmand.fr
GitHub : https://github.com/yvesnet9/vite-gourmand
Trello : https://trello.com/b/TmPyFsmL/vite-gourmand-projet-dwwm

Comptes de démonstration :
  - Admin : admin@demo.fr / Password123!
  - Employé : employe@demo.fr / Password123!
  - Client : client@demo.fr / Password123!
